create definer = root@localhost view meals as
select `mp`.`meal_id`                                              AS `meal_id`,
       `carb`.`name`                                               AS `carb_name`,
       `protein`.`name`                                            AS `prot_name`,
       `vegetable`.`name`                                          AS `vegi_name`,
       coalesce(`other`.`name`, 'None')                            AS `other_name`,
       `carb`.`calories_per_100g`                                  AS `carb_calorie`,
       `protein`.`calories_per_100g`                               AS `prot_calorie`,
       `vegetable`.`calories_per_100g`                             AS `vegi_calorie`,
       coalesce(`other`.`calories_per_100g`, 0)                    AS `other_calorie`,
       `mp`.`proportion`                                           AS `proportion`,
       concat(round((`mp`.`proportion` * (1 / (((1 + 2) + 1) + if((`mp`.`other_id` is null), 0, 1)))), 2), ':',
              round((`mp`.`proportion` * (2 / (((1 + 2) + 1) + if((`mp`.`other_id` is null), 0, 1)))), 2), ':',
              round((`mp`.`proportion` * (1 / (((1 + 2) + 1) + if((`mp`.`other_id` is null), 0, 1)))), 2), ':', round(
                      (`mp`.`proportion` *
                       (if((`mp`.`other_id` is null), 0, 1) / (((1 + 2) + 1) + if((`mp`.`other_id` is null), 0, 1)))),
                      2))                                          AS `ratio`,
       `calculate_component_calories`(`mp`.`meal_id`, 'carb')      AS `calc_carb_calorie`,
       `calculate_component_calories`(`mp`.`meal_id`, 'protein')   AS `calc_prot_calorie`,
       `calculate_component_calories`(`mp`.`meal_id`, 'vegetable') AS `calc_vegi_calorie`,
       `calculate_component_calories`(`mp`.`meal_id`, 'other')     AS `calc_other_calorie`
from ((((`nutri_mithu2`.`meal_plans` `mp` left join `nutri_mithu2`.`food_data` `carb`
         on ((`mp`.`carb_id` = `carb`.`food_id`))) left join `nutri_mithu2`.`food_data` `protein`
        on ((`mp`.`protein_id` = `protein`.`food_id`))) left join `nutri_mithu2`.`food_data` `vegetable`
       on ((`mp`.`vegetable_id` = `vegetable`.`food_id`))) left join `nutri_mithu2`.`food_data` `other`
      on ((`mp`.`other_id` = `other`.`food_id`)));

