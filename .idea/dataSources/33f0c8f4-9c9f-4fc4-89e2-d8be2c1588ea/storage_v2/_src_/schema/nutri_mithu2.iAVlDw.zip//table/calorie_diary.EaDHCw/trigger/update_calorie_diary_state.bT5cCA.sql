create definer = root@localhost trigger update_calorie_diary_state
    before update
    on calorie_diary
    for each row
BEGIN
        IF NEW.date < CURDATE() AND NEW.state = 'pending' THEN
          SET NEW.state = 'missed';
        END IF;
      END;

