create definer = root@localhost trigger after_user_insert
    after insert
    on users
    for each row
BEGIN

  INSERT INTO user_profiles (

    user_id,

    gender,

    date_of_birth,

    height_cm,

    weight_kg,

    dietary_preference,

    allergies,

    ethnicity,

    activity_level,

    current_calories_per_day,

    weight_goal,

    target_weight_kg,

    weight_change_rate,

    bmi

  ) VALUES (

    NEW.user_id,

    'other',  -- Enum: keeping previous value

    CURDATE(),  -- Current date as default

    0,

    0,

    'non_vegetarian',  -- Enum: keeping previous value

    'not set',

    'sri_lankan',  -- Enum: keeping previous value

    'moderate',  -- Enum: keeping previous value

    0,

    'maintain',  -- Enum: keeping previous value

    0,

    '0',  -- Enum: keeping previous value

    NULL  -- Calculated field, keeping as NULL

  );

END;

