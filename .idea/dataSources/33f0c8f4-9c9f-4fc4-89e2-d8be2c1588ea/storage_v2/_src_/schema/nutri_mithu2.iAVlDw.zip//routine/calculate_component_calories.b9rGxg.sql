create
    definer = root@localhost function calculate_component_calories(meal_id int,
                                                                   component_type enum ('carb', 'protein', 'vegetable', 'other')) returns decimal(10, 2)
    deterministic
BEGIN
    DECLARE component_calories DECIMAL(10, 2);
    DECLARE total_ratio DECIMAL(5, 2);
    DECLARE component_cal DECIMAL(10, 2);
    DECLARE component_ratio DECIMAL(5, 2);
    -- Get the proportion and food data
    SELECT 
        mp.proportion,
        fd.calories_per_100g
    INTO 
        total_ratio, component_cal
    FROM 
        meal_plans mp
    JOIN 
        food_data fd ON (
            CASE 
                WHEN component_type = 'carb' THEN mp.carb_id
                WHEN component_type = 'protein' THEN mp.protein_id
                WHEN component_type = 'vegetable' THEN mp.vegetable_id
                ELSE mp.other_id
            END = fd.food_id
        )
    WHERE 
        mp.meal_id = meal_id;
    -- Calculate the ratio
    SET component_ratio = CASE
        WHEN component_type = 'protein' THEN 2
        WHEN component_type = 'other' THEN IF(component_cal > 0, 1, 0)
        ELSE 1
    END / (1 + 2 + 1 + IF(component_type = 'other' AND component_cal > 0, 1, 0));
    -- Calculate the calories for 100 grams
    SET component_calories = ROUND(100 * component_ratio * component_cal / total_ratio, 2);
    RETURN component_calories;
END;

